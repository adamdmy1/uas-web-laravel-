<?php $__env->startSection('content'); ?>

<div class="container">

    <h3>Daftar Pelanggan
    <a class="btn btn-primary btn-sm float-end" href="<?php echo e(url('pelanggan/create')); ?>">
        Tambah Data</a>
    </h3>
    <br>
    <table class="table table-bordered table-hover border-dark text-center">
        <tr class="fw-bold table-active">
            <td>NO PELANGGAN</td>
            <td>NAMA PELANGGAN</td>
            <td>ALAMAT</td>
            <td>NO HP</td>
            <td>JUMLAH PELANGGAN TETAP</td>
            <td>EDIT</td>
            <td>DELETE</td>
        </tr>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="fw-semibold">
            <td><?php echo e($row->pel_no); ?></td>
            <td><?php echo e($row->pel_nama); ?></td>
            <td><?php echo e($row->pel_alamat); ?></td>
            <td><?php echo e($row->pel_hp); ?></td>
            <td><?php echo e($row->pel_tetap); ?></td>
            <td><a href="<?php echo e(url('pelanggan/' . $row->pel_id . '/edit')); ?>" class="btn btn-warning">Edit</a></td>
            <td>
                <form action="<?php echo e(url('pelanggan/' . $row->pel_id)); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UAS-PBWL-AdamDM\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>