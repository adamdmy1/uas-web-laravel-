@extends('layouts.app')

@section('content')
    <div class="container">

         
        <form action="{{ url('/pisang/' . $row->pis_id) }}" method="POST">
            @method('PATCH')
            @csrf
                <div class="mb-3">
                    <label>KODE</label>
                    <input type="text" class="form-control" name="pis_kode" value="{{ $row->pis_kode }}"></>
                </div>
                <div class="mb-3">
                    <label>NAMA</label>
                    <input type="text" class="form-control" name="pis_nama" value="{{ $row->pis_nama }}"></>
                </div>
                <div class="mb-3">
                    <input type="submit" value="UPDATE" class="btn btn-success">
                    <a href="{{ url('pisang/') }}" class="btn btn-secondary">Kembali</a>
                </div>
        </form>
    </div>
@endsection